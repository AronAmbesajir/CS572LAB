import { Component, OnInit } from '@angular/core';

import { GamesDataService } from '../games-data.service';

export class Game {
  _id: number = 1;
  title: string = '';
  price: number = 0;
  minPlayers: number = 0;
  maxPlayers: number = 0;
  minAge: number = 0;

}

@Component({
  selector: 'app-games-list',
  templateUrl: './games-list.component.html',
  styleUrls: ['./games-list.component.css'],
})
export class GamesListComponent implements OnInit {
  title: string = 'Mean Games';
 
  games: Game[] = [];

  constructor(private gamesDataService: GamesDataService) {}

  ngOnInit(): void {
    this.getGames();
  }

  private getGames(): void {
    this.gamesDataService
      .getGames()
      .then((response) => this.gotGames(this, response))
      .catch(this.handleError);
  }
  private gotGames(gamesListComponent: GamesListComponent, response: Game[]) {
    gamesListComponent.games = response;
  }

  private handleError(error: any) {
    console.log(error);
  }
}
