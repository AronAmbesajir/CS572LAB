
Angular version from mean game project
GetAllGames and GetOneGame