Angular version from mean airplane project
GetAllAirplanes and GetOneAirplane