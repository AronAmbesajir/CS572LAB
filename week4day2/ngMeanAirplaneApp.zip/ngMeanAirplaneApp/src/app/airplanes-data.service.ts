import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Airplane } from './airplanes-list/airplanes-list.component';

@Injectable({
  providedIn: 'root',
})
export class AirplanesDataService {
  private baseURL: string = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  public getAirplanes(): Promise<Airplane[]> {
    //1- Build URL
    const url: string = this.baseURL + '/airplanes';
    //2- Tell HTTP service to make a request
    //3- convert the observable to a promise
    //4- convert the response to JSON
    //5- Return the response
    //6- Catch and handle errors
    return this.http
      .get(url)
      .toPromise()
      .then(this.gotAirplanes)
      .catch(this.handleError);
  }
  private gotAirplanes(response: any): Airplane[] {
    console.log(response);
    return response as Airplane[];
  }

  private handleError(error: any): Airplane[] {
    console.log('Error ', error);
    return [];
  }

  public getAirplane(airplaneId: string): Promise<Airplane> {
    const url: string = this.baseURL + '/airplanes/' + airplaneId;

    return this.http
      .get(url)
      .toPromise()
      .then(this.gotAirplane)
      .catch(this.handleError2);
  }

  private gotAirplane(response: any): Airplane {
    return response as Airplane;
  }

  private handleError2(error: any): Airplane {
    console.log('Error ', error);
    return {} as Airplane;
  }
}
