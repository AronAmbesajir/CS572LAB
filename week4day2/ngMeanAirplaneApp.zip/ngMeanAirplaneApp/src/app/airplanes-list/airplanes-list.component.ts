import { Component, OnInit } from '@angular/core';

import { AirplanesDataService } from '../airplanes-data.service';

export class Airplane {
  _id: number = 1;
  modelNum: string = '';
  capacity: number = 0;
  manufacture: string = '';
  
}

@Component({
  selector: 'app-airplanes-list',
  templateUrl: './airplanes-list.component.html',
  styleUrls: ['./airplanes-list.component.css'],
})
export class AirplanesListComponent implements OnInit {
  title: string = 'Mean Airplanes';
 
  airplanes: Airplane[] = [];

  constructor(private airplanesDataService: AirplanesDataService) {}

  ngOnInit(): void {
    this.getAirplanes();
  }

  private getAirplanes(): void {
    this.airplanesDataService
      .getAirplanes()
      .then((response) => this.gotAirplanes(this, response))
      .catch(this.handleError);
  }
  private gotAirplanes(airplanesListComponent: AirplanesListComponent, response: Airplane[]) {
    airplanesListComponent.airplanes = response;
  }

  private handleError(error: any) {
    console.log(error);
  }
}
