import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { AirplanesDataService } from '../airplanes-data.service';
import { Airplane } from '../airplanes-list/airplanes-list.component';

@Component({
  selector: 'app-airplane-details',
  templateUrl: './airplane-details.component.html',
  styleUrls: ['./airplane-details.component.css'],
})
export class AirplaneDetailsComponent implements OnInit {
  airplane: Airplane = {} as Airplane;

  constructor(
    private airplanesDataService: AirplanesDataService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const airplaneId: string = this.route.snapshot.params.airplaneId;
    this.getAirplane(airplaneId);
  }

  private getAirplane(airplaneId: string): void {
    this.airplanesDataService
      .getAirplane(airplaneId)
      .then((response) => this.gotAirplane(this, response))
      .catch(this.handleError);
  }

  private gotAirplane(airplaneDetailsComponent: AirplaneDetailsComponent, response: Airplane) {
    airplaneDetailsComponent.airplane= response;
  }

  private handleError(error: any) {
    console.log(error);
  }
}
