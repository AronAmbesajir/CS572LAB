import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AirplanesListComponent } from './airplanes-list/airplanes-list.component';
import { OrderPipe } from './order.pipe';
import { HomePageComponent } from './home-page/home-page.component';
import { componentFactoryName } from '@angular/compiler';
import { AirplaneDetailsComponent } from './airplane-details/airplane-details.component';

@NgModule({
  declarations: [
    AppComponent,
    AirplanesListComponent,
    OrderPipe,
    HomePageComponent,
    AirplaneDetailsComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path: '',
        component: HomePageComponent,
      },
      {
        path: 'airplanes',
        component: AirplanesListComponent,
      },
      {
        path: 'airplanes/:airplaneId',
        component: AirplaneDetailsComponent,
      },
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
